# Merged All Core Ontology

This directory contains merged copies of the full releases of CCO. Each file contains all the content of the eleven mid-level ontologies, along with BFO and the subset of RO used in CCO. MRO is not included. Each file represents a stable snapshot release of CCO with no external dependencies required for use.
